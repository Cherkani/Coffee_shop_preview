"use client"

import { useLanguage } from "@/lib/i18n"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Languages, Check } from "lucide-react"
import { getLanguageDisplayName } from "@/lib/i18n/utils"
import type { Language } from "@/lib/i18n/types"

interface LanguageSwitcherProps {
  variant?: "default" | "ghost" | "outline"
  size?: "default" | "sm" | "lg"
  showLabel?: boolean
}

export function LanguageSwitcher({ variant = "ghost", size = "default", showLabel = false }: LanguageSwitcherProps) {
  const { language, setLanguage, t } = useLanguage()

  const languages: Language[] = ["en", "fr"]

  const handleLanguageChange = (newLanguage: Language) => {
    setLanguage(newLanguage)
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant={variant} size={size} className="gap-2">
          <Languages className="h-4 w-4" />
          {showLabel && <span className="hidden sm:inline">{getLanguageDisplayName(language)}</span>}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-40">
        {languages.map((lang) => (
          <DropdownMenuItem
            key={lang}
            onClick={() => handleLanguageChange(lang)}
            className="flex items-center justify-between cursor-pointer"
          >
            <span>{getLanguageDisplayName(lang)}</span>
            {language === lang && <Check className="h-4 w-4" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

// Compact version for mobile/small spaces
export function LanguageSwitcherCompact() {
  const { language, setLanguage } = useLanguage()

  const toggleLanguage = () => {
    setLanguage(language === "en" ? "fr" : "en")
  }

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={toggleLanguage}
      className="h-8 w-8 p-0"
      title={`Switch to ${language === "en" ? "Français" : "English"}`}
    >
      <span className="text-xs font-medium">{language.toUpperCase()}</span>
    </Button>
  )
}
