"use client"

import { useAppStore } from "@/lib/store"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  ShoppingCart,
  Monitor,
  BarChart3,
  Package,
  Users,
  Settings,
  Coffee,
  Clock,
  TrendingUp,
  Warehouse,
  Receipt,
  Calendar,
  DollarSign,
  MapPin,
  Truck,
  Store,
  Factory,
  ShoppingBag,
} from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useTranslation } from "@/lib/i18n"

const navigationItems = {
  superuser: [
    { name: "nav.console", href: "/console", icon: LayoutDashboard },
    { name: "nav.organizations", href: "/organizations", icon: Coffee },
    { name: "nav.users", href: "/users", icon: Users },
    { name: "nav.analytics", href: "/analytics", icon: TrendingUp },
    { name: "nav.settings", href: "/settings", icon: Settings },
  ],
  owner: [
    { name: "nav.dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "nav.locations", href: "/locations", icon: MapPin },
    { name: "nav.reports", href: "/reports", icon: BarChart3 },
    { name: "nav.analytics", href: "/analytics", icon: TrendingUp },
    { name: "nav.catalog", href: "/catalog", icon: Package },
    { name: "nav.staff", href: "/staff", icon: Users },
    { name: "nav.payroll", href: "/payroll", icon: DollarSign },
    { name: "nav.scheduling", href: "/scheduling", icon: Calendar },
    { name: "nav.suppliers", href: "/suppliers", icon: Truck },
    { name: "nav.marketplace", href: "/marketplace", icon: Store },
    { name: "nav.procurement", href: "/procurement", icon: ShoppingBag },
    { name: "nav.settings", href: "/settings", icon: Settings },
  ],
  admin: [
    { name: "nav.dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "nav.reports", href: "/reports", icon: BarChart3 },
    { name: "nav.catalog", href: "/catalog", icon: Package },
    { name: "nav.inventory", href: "/inventory", icon: Warehouse },
    { name: "nav.staff", href: "/staff", icon: Users },
    { name: "nav.scheduling", href: "/scheduling", icon: Calendar },
    { name: "nav.timeclock", href: "/timeclock", icon: Clock },
    { name: "nav.transactions", href: "/transactions", icon: Receipt },
    { name: "nav.production", href: "/production", icon: Factory },
    { name: "nav.marketplace", href: "/marketplace", icon: Store },
    { name: "nav.procurement", href: "/procurement", icon: ShoppingBag },
  ],
  cashier: [
    { name: "nav.pos", href: "/pos", icon: ShoppingCart },
    { name: "nav.kds", href: "/kds", icon: Monitor },
    { name: "nav.timeclock", href: "/timeclock", icon: Clock },
    { name: "common.mySales", href: "/reports", icon: BarChart3 },
    { name: "nav.transactions", href: "/transactions", icon: Receipt },
  ],
}

export function Sidebar() {
  const { currentUser } = useAppStore()
  const pathname = usePathname()
  const { t } = useTranslation()

  if (!currentUser) return null

  const items = navigationItems[currentUser.role] || []

  return (
    <div className="w-64 bg-card border-r border-border h-full">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-8">
          <Coffee className="h-8 w-8 text-orange-500" />
          <span className="text-xl font-semibold">CoffeePOS</span>
        </div>

        <nav className="space-y-2">
          {items.map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.href

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                  isActive
                    ? "bg-secondary text-secondary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary/50",
                )}
              >
                <Icon className="h-4 w-4" />
                {t(item.name)}
              </Link>
            )
          })}
        </nav>
      </div>
    </div>
  )
}
