export type Language = "en" | "fr"

export interface TranslationKeys {
  // Common
  common: {
    loading: string
    save: string
    cancel: string
    delete: string
    edit: string
    add: string
    search: string
    filter: string
    export: string
    import: string
    settings: string
    logout: string
    login: string
    email: string
    password: string
    name: string
    description: string
    price: string
    quantity: string
    total: string
    date: string
    time: string
    status: string
    actions: string
    confirm: string
    back: string
    next: string
    previous: string
    close: string
    open: string
    yes: string
    no: string
  }

  // Navigation
  nav: {
    dashboard: string
    pos: string
    catalog: string
    inventory: string
    staff: string
    reports: string
    analytics: string
    settings: string
    console: string
    kds: string
    timeclock: string
    scheduling: string
    payroll: string
    transactions: string
    locations: string
    suppliers: string
    procurement: string
    production: string
    marketplace: string
    organizations: string
    users: string
  }

  // POS System
  pos: {
    title: string
    cart: string
    checkout: string
    payment: string
    cash: string
    card: string
    addToCart: string
    removeFromCart: string
    clearCart: string
    orderTotal: string
    tax: string
    subtotal: string
    discount: string
    tip: string
    change: string
    receipt: string
    orderComplete: string
    orderNumber: string
    customer: string
    dineIn: string
    takeout: string
    delivery: string
  }

  // Dashboard
  dashboard: {
    title: string
    todaySales: string
    totalOrders: string
    averageOrder: string
    topProducts: string
    recentOrders: string
    salesChart: string
    overview: string
    quickActions: string
  }

  // Staff Management
  staff: {
    title: string
    addStaff: string
    editStaff: string
    deleteStaff: string
    firstName: string
    lastName: string
    role: string
    phone: string
    address: string
    hireDate: string
    salary: string
    hourlyRate: string
    permissions: string
    active: string
    inactive: string
  }

  // Inventory
  inventory: {
    title: string
    addProduct: string
    editProduct: string
    deleteProduct: string
    category: string
    sku: string
    cost: string
    stock: string
    lowStock: string
    outOfStock: string
    reorderLevel: string
    supplier: string
    lastUpdated: string
  }

  // Reports
  reports: {
    title: string
    salesReport: string
    inventoryReport: string
    staffReport: string
    financialReport: string
    dateRange: string
    generateReport: string
    downloadReport: string
    revenue: string
    profit: string
    expenses: string
    growth: string
  }

  // Settings
  settings: {
    title: string
    general: string
    appearance: string
    notifications: string
    security: string
    language: string
    theme: string
    currency: string
    timezone: string
    taxRate: string
    businessInfo: string
    businessName: string
    businessAddress: string
    businessPhone: string
    businessEmail: string
  }

  // Authentication
  auth: {
    signIn: string
    signOut: string
    signUp: string
    forgotPassword: string
    resetPassword: string
    rememberMe: string
    createAccount: string
    welcomeBack: string
    enterCredentials: string
    invalidCredentials: string
    accountCreated: string
    passwordReset: string
  }

  // Messages
  messages: {
    success: string
    error: string
    warning: string
    info: string
    confirmDelete: string
    itemAdded: string
    itemUpdated: string
    itemDeleted: string
    changesSaved: string
    operationFailed: string
    networkError: string
    unauthorized: string
    notFound: string
  }
}
