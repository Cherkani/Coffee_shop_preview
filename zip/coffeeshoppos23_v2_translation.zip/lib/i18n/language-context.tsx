"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import type { Language } from "./types"
import { translate, detectBrowserLanguage } from "./utils"

interface LanguageContextType {
  language: Language
  setLanguage: (language: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

interface LanguageProviderProps {
  children: React.ReactNode
  defaultLanguage?: Language
}

export function LanguageProvider({ children, defaultLanguage }: LanguageProviderProps) {
  const [language, setLanguageState] = useState<Language>(() => {
    // Check localStorage first, then default language, then browser language
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("coffee-pos-language") as Language
      if (stored && ["en", "fr"].includes(stored)) {
        return stored
      }
    }
    return defaultLanguage || detectBrowserLanguage()
  })

  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage)
    if (typeof window !== "undefined") {
      localStorage.setItem("coffee-pos-language", newLanguage)
      // Update document language attribute
      document.documentElement.lang = newLanguage
    }
  }

  const t = (key: string): string => {
    return translate(language, key)
  }

  useEffect(() => {
    // Set initial document language
    if (typeof window !== "undefined") {
      document.documentElement.lang = language
    }
  }, [language])

  const value: LanguageContextType = {
    language,
    setLanguage,
    t,
  }

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>
}

export function useLanguage(): LanguageContextType {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}

// Convenience hook for just the translation function
export function useTranslation() {
  const { t } = useLanguage()
  return { t }
}
