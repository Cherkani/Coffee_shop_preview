import { en } from "./en"
import { fr } from "./fr"
import type { Language, TranslationKeys } from "../types"

export const translations: Record<Language, TranslationKeys> = {
  en,
  fr,
}

export { en, fr }
