import type { Language } from "./types"
import { translations } from "@/lib/i18n/translations"

export function getNestedValue(obj: any, path: string): string {
  return path.split(".").reduce((current, key) => current?.[key], obj) || path
}

export function translate(language: Language, key: string): string {
  const translation = translations[language]
  if (!translation) {
    console.warn(`Translation not found for language: ${language}`)
    return key
  }

  const value = getNestedValue(translation, key)
  if (typeof value !== "string") {
    console.warn(`Translation key not found: ${key} for language: ${language}`)
    return key
  }

  return value
}

export function getLanguageDisplayName(language: Language): string {
  const displayNames: Record<Language, string> = {
    en: "English",
    fr: "Français",
  }
  return displayNames[language] || language
}

export function detectBrowserLanguage(): Language {
  if (typeof window === "undefined") return "en"

  const browserLang = navigator.language.split("-")[0] as Language
  return ["en", "fr"].includes(browserLang) ? browserLang : "en"
}
